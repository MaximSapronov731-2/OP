﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace desktop
{
    public partial class Form2 : Form
    {
        private char[] characters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F',
            'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
            'R', 'S', 'T', 'U' ,'V', 'W', 'X', 'Y',
            'Z', ' ', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', '0' };

        private int N;
        public Form2()
        {
            InitializeComponent();
            N = characters.Length;
        }
        public string Encode(string input, string keyword)
        {
            input = input.ToUpper();
            keyword = keyword.ToUpper();

            string result = "";

            int keyword_index = 0;

            foreach (char symbol in input)
            {
                int c = (Array.IndexOf(characters, symbol) +
                         Array.IndexOf(characters, keyword[keyword_index])) % N;

                result += characters[c];

                keyword_index++;

                if ((keyword_index) == keyword.Length)
                    keyword_index = 0;
            }

            return result;
        }

        public string Decode(string input, string keyword)
        {
            input = input.ToUpper();
            keyword = keyword.ToUpper();

            string result = "";

            int keyword_index = 0;

            foreach (char symbol in input)
            {
                int p = (Array.IndexOf(characters, symbol) + N -
                         Array.IndexOf(characters, keyword[keyword_index])) % N;

                result += characters[p];

                keyword_index++;

                if ((keyword_index) == keyword.Length)
                    keyword_index = 0;
            }

            return result;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Введите ключ и текст");
                return;
            }
            string result = Encode(textBox2.Text, textBox1.Text);
            StreamWriter writer = new StreamWriter("Шифровка.txt");
            writer.WriteLine(result);
            writer.Close();
            MessageBox.Show("Результат сохранён в файл");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Введите ключ и текст");
                return;
            }
            string readString = "";
            try
            {
                StreamReader reader = new StreamReader("Шифровка.txt");
                readString = reader.ReadLine();
                reader.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка при чтении файла Шифровка.txt");
                return;
            }
            string result = Decode(readString, textBox1.Text);
            StreamWriter writer = new StreamWriter("Расшифровка.txt");
            writer.WriteLine(result);
            writer.Close();
            MessageBox.Show("Результат сохранён в файл");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Form1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Шифр Виженера состоит из последовательности нескольких шифров Цезаря с различными значениями сдвига. При помощи ключевого слова циклически шифруется сообщение до тех пор, пока его длина не будет соответствовать длине исходного текста. Для примера: к первой букве текста применяется преобразование, например, сдвиг на 1 (буква B), ко второй, например, сдвиг на 7 (буква G), и так далее. Значения сдвига задаются введённым ключом.                                                                                                                                           " +
                "Как пользователь программой:                                                                                                                                                                     " +
                "1)Введите ключ и текст  " +
                "2)Нажмите кнопку ЗАШИФРОВАТЬ И РАСШИФРОВАТЬ  " +
                "3)Перейдите в корневую папку и откройте два файла ШИФРОВКА И РАСШИФРОВКА  ");
        }
    }
}