﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktop
{
    public partial class Form1 : Form
    {
        bool vis = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (vis)
            {     
                passwordField.UseSystemPasswordChar = false;
                vis = false;
            }  
            else
            {
                passwordField.UseSystemPasswordChar = true;
                vis = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (loginField.Text == "")
            {
                MessageBox.Show("Введите логин");
                return;
            }
            if (passwordField.Text == "")
            {
                MessageBox.Show("Введите пароль");
                return;
            }
            String loginUser = loginField.Text;
            String passwordUser = passwordField.Text;

            if (check(loginUser,passwordUser))
			{
                MessageBox.Show("Вход выполнен");
                Form Form2 = new Form2();
                Form2.Show();
                this.Hide();
            }
			else
			{
                MessageBox.Show("Неверный логин или пароль");
            }
        }
        public Boolean check(string login,string password)
		{
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `login` = @uL AND `password` = @uP", db.getConnection());
            command.Parameters.Add("@uL", MySqlDbType.VarChar).Value = login;
            command.Parameters.Add("@uP", MySqlDbType.VarChar).Value = password;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                return true;

            }
            else
                return false;
		}

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form RegistrationForm3 = new RegistrationForm3();
            RegistrationForm3.Show();
            this.Hide();
        }
    }

}
      