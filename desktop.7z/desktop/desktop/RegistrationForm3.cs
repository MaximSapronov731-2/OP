﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktop
{
    public partial class RegistrationForm3 : Form
    {
        bool vis = true;
        public RegistrationForm3()
        {
            InitializeComponent();
            login.Text = "Введите имя";
            password.Text = "Введите фамилию";
            login.ForeColor = Color.Gray;
            password.ForeColor = Color.Gray;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (vis)
            {
                passwordField.UseSystemPasswordChar = false;
                vis = false;
            }
            else
            {
                passwordField.UseSystemPasswordChar = true;
                vis = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Form1.Show();
            this.Hide();
        }

        private void RegistrationForm3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameBox_Enter(object sender, EventArgs e)
        {
            if  (login.Text == "Введите имя")
            {    
             login.Text = "";
            }
        }

        private void nameBox_Leave(object sender, EventArgs e)
        {
            if (login.Text == "")
            {
                login.Text = "Введите имя";
            }
        }

        private void surnameBox_Enter(object sender, EventArgs e)
        {
            if (password.Text == "Введите фамилию")
            {
                password.Text = "";
            }
        }

        private void surnameBox_Leave(object sender, EventArgs e)
        {
            if (password.Text == "")
            {
                password.Text = "Введите фамилию";
            }
        }

        public void button1_Click(object sender, EventArgs e)
        {
            if (login.Text == "Введите имя")
            {
                MessageBox.Show("Введите имя");
                return;
            }
            if (password.Text == "Введите фамилию")
            {
                MessageBox.Show("Введите фамилию");
                return;
            }
            if (loginField.Text == "")
            {
                MessageBox.Show("Введите логин");
                return;
            }
            if (passwordField.Text == "")
            {
                MessageBox.Show("Введите пароль");
                return;
            }
            if (isUserExists(loginField.Text))
			{
                MessageBox.Show("Логин уже используется, введите другой");
                return;
            }                
                


            DB db = new DB();
            MySqlCommand command = new MySqlCommand("INSERT INTO `users` (`login`, `password`, `name`, `surname`) VALUES (@login, @password, @name, @surname)", db.getConnection());
            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = loginField.Text;
            command.Parameters.Add("@password", MySqlDbType.VarChar).Value = passwordField.Text;
            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = login.Text;
            command.Parameters.Add("@surname", MySqlDbType.VarChar).Value = password.Text;

            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Аккаунт создан");
                Form Form1 = new Form1();
                Form1.Show();
                this.Hide();
            }

            else MessageBox.Show("Ошибка. Аккаунт не создан");

            db.closeConnection();
        }

        public Boolean isUserExists(string login)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `login` = @uL", db.getConnection());
            command.Parameters.Add("@uL", MySqlDbType.VarChar).Value = login;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                
                return true;
            }

            else
            {    
                return false;
            }

        }

    }
}
