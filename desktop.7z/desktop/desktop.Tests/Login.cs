﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace desktop.Tests
{
	[TestClass]
	public class Login
	{
		[TestMethod]
		public void Input_Admin()
		{
			string login = "123"; // свой логин
			string password = "123"; // свой пароль
			Boolean expected = true;
			Form1 test = new Form1();
			Boolean actual = test.check(login, password);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Input_WrongPasswordAdmin()
		{
			string login = "445пп43е3"; //  не свой логин и не свой пароль
			string password = "папавпв"; 
			Boolean expected = false;
			Form1 test = new Form1();
			Boolean actual = test.check(login, password);
			Assert.AreEqual(expected, actual);
		}
	}
}
