﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace desktop.Tests
{
	[TestClass]
	public class Encrypt
	{
		[TestMethod]
		public void Encode_KeyABC_TextHello()
		{
			string key = "ABC";
			string text = "Hello";
			string expected = "HFNLP";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_KeyABC()
		{
			string key = "ABC";
			string text = "H e l l o";
			string expected = "H1G M2L1Q";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_Keybbbb_Textbbbbbb()
		{
			string key = "bbbb";
			string text = "bbbbbb";
			string expected = "CCCCCC";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_Keyabc_Textbbbbbb()
		{
			string key = "abc";
			string text = "bbbbbb";
			string expected = "BCDBCD";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_Keya_TextB2V()
		{
			string key = "a";
			string text = "b2v";
			string expected = "B2V";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_KeyBACDEG()
		{
			string key = "BACDEG";
			string text = "ABCDEFG";
			string expected = "BBEGILH";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Encode_Key____()
		{
			string key = "    ";
			string text = "ABCD";
			string expected = " 123";
			Form2 test = new Form2();
			string actual = test.Encode(text, key);
			Assert.AreEqual(expected, actual);
		}
	}
}
