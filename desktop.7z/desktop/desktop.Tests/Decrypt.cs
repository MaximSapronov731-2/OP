﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace desktop.Tests
{
	[TestClass]
	public class Decrypt
	{
		[TestMethod]
		public void Decode_keybbb()
		{
			string key = "bbb";
			string text = "bbb";
			string expected = "aaa";
			expected=expected.ToUpper();
			Form2 test = new Form2();
			string actual = test.Decode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Decode_keyabc()
		{
			string key = "abc";
			string text = "London";
			string expected = "LNLDNL";
			expected = expected.ToUpper();
			Form2 test = new Form2();
			string actual = test.Decode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Decode_keyb_TextHelloween()
		{
			string key = "b";
			string text = "Helloween";
			string expected = "GDKKNVDDM";
			expected = expected.ToUpper();
			Form2 test = new Form2();
			string actual = test.Decode(text, key);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Decode_keyaja()
		{
			string key = "ajA";
			string text = "A0a";
			string expected = "A1A";
			expected = expected.ToUpper();
			Form2 test = new Form2();
			string actual = test.Decode(text, key);
			Assert.AreEqual(expected, actual);
		}
	}
}
