﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace desktop.Tests
{
	[TestClass]
	public class RegistrationBOXES
	{
		[TestMethod]
		public void Reg_Admin()
		{
			string login = "123"; // проверка на зарег. пользователя с таким логином
			bool expected = true;
			RegistrationForm3 test = new RegistrationForm3();
			bool actual = test.isUserExists(login);
			Assert.AreEqual(expected, actual);
		}
		[TestMethod]
		public void Reg_New()
		{
			string login = "ahahaahahaah"; 
			bool expected = false;
			RegistrationForm3 test = new RegistrationForm3();
			bool actual = test.isUserExists(login);
			Assert.AreEqual(expected, actual);
		}
	}
}
